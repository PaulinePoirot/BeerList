package com.example.pauli.beerlist;

/**
 * Created by pauli on 23/03/2018.
 */

public class Beer {

    private String id;
    private String name;
    private String createDate;
    private String description;
    private String updateDate;
    private String note;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public Beer(String id, String name, String createDate, String description, String updateDate, String note
    ) {
        this.id = id;
        this.name = name;
        this.createDate = createDate;
        this.description = description;
        this.updateDate = updateDate;
        this.note = note;

    }
}
